//
//  Fetch_iOS_ExerciseApp.swift
//  Fetch iOS Exercise
//
//  Created by Aatif Ullah on 9/4/24.
//

import SwiftUI

@main
struct Fetch_iOS_ExerciseApp: App {
    var body: some Scene {
        WindowGroup {
            RecipesView()
        }
    }
}
